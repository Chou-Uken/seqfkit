<!--
 * @Author: Chou_Uken Chouuken@outlook.com
 * @Date: 2024-12-13 13:45:28
 * @LastEditors: Chou_Uken Chouuken@outlook.com
 * @LastEditTime: 2024-12-15 22:37:12
 * @FilePath: /seqfkit/README.md
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
# seqfkit

Some useful tools to handle sequences (DNA/RNA/Protein).
